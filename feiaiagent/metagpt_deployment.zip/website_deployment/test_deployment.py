#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MetaGPT部署测试脚本
"""

import requests
import json
import time

def test_local():
    """测试本地应用"""
    print("🧪 测试本地应用...")
    
    base_url = "http://localhost:5000"
    
    tests = [
        ("健康检查", f"{base_url}/api/health", "GET"),
        ("MetaGPT状态", f"{base_url}/api/metagpt/status", "GET"),
        ("MetaGPT初始化", f"{base_url}/api/metagpt/init", "POST"),
        ("对话启动", f"{base_url}/api/metagpt_agent/start_conversational", "POST")
    ]
    
    for name, url, method in tests:
        try:
            if method == "GET":
                response = requests.get(url, timeout=10)
            else:
                data = {"session_id": f"test_{int(time.time())}"}
                response = requests.post(url, json=data, timeout=10)
            
            if response.status_code == 200:
                print(f"✅ {name}")
            else:
                print(f"❌ {name}: {response.status_code}")
        except Exception as e:
            print(f"❌ {name}: {e}")

if __name__ == "__main__":
    test_local()
